@extends('shop::base')

@section('aimeos_header')
     <?= $aiheader['checkout/standard'] ?>
@stop

@section('aimeos_body')
    <?= $aibody['checkout/standard'] ?>
@stop
