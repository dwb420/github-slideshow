@extends('shop::base')

@section('aimeos_header')
     <?= $aiheader['checkout/confirm'] ?>
@stop

@section('aimeos_body')
    <?= $aibody['checkout/confirm'] ?>
@stop
